public class FastCollinearPoints {
    public FastCollinearPoints(Point[] points) {

    }     // finds all line segments containing 4 or more points

    public int numberOfSegments() {
        return 0;

    }       // the number of line segments

    public LineSegment[] segments() {
        return null;
    }      // the line segments
}
